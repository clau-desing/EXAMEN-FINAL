package com.regalado.ex.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.regalado.ex.entity.Usuario;
import com.regalado.ex.exception.GeneralException;
import com.regalado.ex.exception.NoDataFoundException;
import com.regalado.ex.exception.ValidateException;
import com.regalado.ex.repository.UsuarioRepository;
import com.regalado.ex.service.UsuarioService;
import com.regalado.ex.util.Encoder;
import com.regalado.ex.validator.UsuarioValidator;

@Service
public class UsuarioServiceImpl implements UsuarioService {
	@Autowired
	private UsuarioRepository repository;
	
	@Autowired
	private Encoder encoder;

	@Override
	@Transactional(readOnly = true)
	public List<Usuario> findAll(Pageable page) {
		try {
			List<Usuario> registros = repository.findAll(page).toList();
			return registros;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional(readOnly = true)
	public List<Usuario> findAll() {
		try {
			List<Usuario> registros = repository.findAll();
			return registros;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional(readOnly = true)
	public Usuario findByEmail(String email) {
		try {
			Usuario registro = repository.findByEmail(email);
			if (registro == null) {
				throw new NoDataFoundException("Error del servidor");
			}
			return registro;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional(readOnly = true)
	public Usuario findById(int id) {
		try {
			Usuario registro = repository.findById(id)
					.orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
			return registro;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional
	public Usuario save(Usuario usuario) {
		try {

			
			// Nuevo registro
			if (usuario.getId() == 0) {
				usuario.setActivo(true);
				usuario.setPassword(encoder.encodePassword(usuario.getPassword()));
				Usuario nuevo = repository.save(usuario);				
				return nuevo;
			}
			// editar registro
			Usuario registro = repository.findById(usuario.getId())
					.orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
			registro.setEmail(usuario.getEmail());
			String pass=encoder.encodePassword(usuario.getPassword());
			registro.setPassword(pass);
			repository.save(registro);
			return registro;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional
	public Usuario deactivate(int id) {
		try {
			Usuario registro = repository.findById(id)
					.orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
			registro.setActivo(false);
			repository.save(registro);
			return registro;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}

	@Override
	@Transactional
	public Usuario activate(int id) {
		try {
			Usuario registro = repository.findById(id)
					.orElseThrow(() -> new NoDataFoundException("No existe un registro con ese ID"));
			registro.setActivo(true);
			repository.save(registro);
			return registro;
		} catch (ValidateException | NoDataFoundException e) {
			throw e;
		} catch (GeneralException e) {
			throw new GeneralException("Error del servidor");
		}
	}
}
